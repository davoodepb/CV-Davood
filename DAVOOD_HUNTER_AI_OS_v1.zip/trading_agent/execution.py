# ============================================================
#  DAVOOD HUNTER AI OS v1.0 — EXECUTION ENGINE
#  Paper Broker (default) + CCXT + MT5
# ============================================================

from datetime import datetime, timezone
from config import BROKER, EXCHANGE_API_KEY, EXCHANGE_SECRET, PAPER_MODE
from risk_manager import calculate_lot_size
from journal import log_trade_open


class PaperBroker:
    def __init__(self):
        self.balance = 10_000.0
        self.orders = []
        print("[PAPER] Paper broker active — Balance: $10,000")

    def get_balance(self):
        return self.balance

    def place_order(self, symbol, side, lot_size, entry, sl, tp):
        order = {
            "id": f"PAPER-{len(self.orders)+1:04d}",
            "symbol": symbol, "side": side,
            "lot_size": lot_size, "entry": entry,
            "sl": sl, "tp": tp, "status": "filled",
            "time": datetime.now(timezone.utc).isoformat()
        }
        self.orders.append(order)
        print(f"[PAPER] ✅ {side} {lot_size} {symbol} @ {entry} | SL:{sl} TP:{tp}")
        return order


class CCXTBroker:
    def __init__(self):
        try:
            import ccxt
            self.exchange = ccxt.bybit({
                "apiKey": EXCHANGE_API_KEY,
                "secret": EXCHANGE_SECRET,
                "enableRateLimit": True,
            })
            print(f"[CCXT] Connected to Bybit")
        except ImportError:
            raise ImportError("Run: pip install ccxt")

    def get_balance(self):
        b = self.exchange.fetch_balance()
        return float(b.get("USDT", {}).get("free", 0))

    def place_order(self, symbol, side, lot_size, entry, sl, tp):
        order = self.exchange.create_order(
            symbol=symbol, type="limit",
            side=side.lower(), amount=lot_size, price=entry,
            params={"stopLoss": {"triggerPrice": sl}, "takeProfit": {"triggerPrice": tp}}
        )
        print(f"[CCXT] ✅ Order {order['id']} — {side} {lot_size} @ {entry}")
        return order


def get_broker():
    if PAPER_MODE:
        print("[BROKER] PAPER MODE — No real money at risk")
        return PaperBroker()
    elif "ccxt" in BROKER.lower() or "bybit" in BROKER.lower():
        return CCXTBroker()
    else:
        print("[BROKER] Unknown broker — defaulting to paper")
        return PaperBroker()


def execute_trade(decision: dict, alert_data: dict, broker, decision_id: int) -> dict:
    symbol  = alert_data.get("symbol", "XAUUSD")
    side    = decision["action"]
    entry   = float(decision["entry"])
    sl      = float(decision["sl"])
    tp      = float(decision["tp"])

    try:
        balance = broker.get_balance()
    except:
        balance = 10_000.0

    lot_size, risk_usd = calculate_lot_size(balance, entry, sl, symbol)
    print(f"[EXEC] {side} {symbol} | Entry:{entry} SL:{sl} TP:{tp} | Lot:{lot_size} Risk:${risk_usd}")

    try:
        order = broker.place_order(symbol, side, lot_size, entry, sl, tp)
        trade_id = log_trade_open(
            decision_id=decision_id, symbol=symbol, side=side,
            entry=entry, sl=sl, tp=tp, lot_size=lot_size, risk_usd=risk_usd
        )
        return {"success": True, "trade_id": trade_id, "order_id": order.get("id"),
                "lot_size": lot_size, "risk_usd": risk_usd}
    except Exception as e:
        print(f"[EXEC] ❌ Order failed: {e}")
        return {"success": False, "error": str(e)}
