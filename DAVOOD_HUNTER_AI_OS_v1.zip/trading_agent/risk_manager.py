# ============================================================
#  DAVOOD HUNTER AI OS v1.0 — RISK MANAGER
#  Hard Rules enforcer + Kill Switch + Lot Calculator
# ============================================================

import math
from datetime import datetime, timezone
from config import (
    RISK_PER_TRADE_PCT, MIN_RR_RATIO, MAX_DAILY_LOSS_PCT,
    MAX_OPEN_TRADES, MIN_SCORE, MIN_CONFIDENCE, KILLZONES
)
from journal import get_daily_pnl_pct, get_open_trade_count

_KILL_SWITCH = False
_KILL_REASON = ""


def activate_kill_switch(reason: str = "manual"):
    global _KILL_SWITCH, _KILL_REASON
    _KILL_SWITCH = True
    _KILL_REASON = reason
    print(f"[KILL SWITCH] ACTIVATED — {reason}")


def reset_kill_switch():
    global _KILL_SWITCH, _KILL_REASON
    _KILL_SWITCH = False
    _KILL_REASON = ""
    print("[KILL SWITCH] Reset by operator.")


def is_killed() -> bool:
    return _KILL_SWITCH


def in_killzone() -> tuple:
    utc_hour = datetime.now(timezone.utc).hour
    for zone, (start, end) in KILLZONES.items():
        if start <= utc_hour < end:
            return True, zone
    return False, "None"


def approve_trade(decision: dict, account_balance: float) -> tuple:
    """
    Returns (approved: bool, reason: str)
    Enforces ALL Hard Rules from Module 10 of DAVOOD OS
    """

    # Kill switch
    if is_killed():
        return False, f"Kill switch active: {_KILL_REASON}"

    # HARD RULE: action must be directional
    if decision.get("action") == "WAIT":
        return False, "AI decision: WAIT"

    # HARD RULE: AI Score minimum 80
    score = decision.get("score") or 0
    if score < MIN_SCORE:
        return False, f"Score {score}/100 below minimum {MIN_SCORE}"

    # HARD RULE: Kill zone must be active
    if not decision.get("killzone_active"):
        return False, "No active kill zone (London/NY)"

    # HARD RULE: Sweep must be confirmed
    if not decision.get("sweep_confirmed"):
        return False, "Liquidity sweep not confirmed"

    # HARD RULE: Displacement must be confirmed
    if not decision.get("displacement_confirmed"):
        return False, "Displacement candle not confirmed"

    # HARD RULE: Confidence minimum
    conf = decision.get("confidence") or 0
    if conf < MIN_CONFIDENCE:
        return False, f"Confidence {conf}% below minimum {MIN_CONFIDENCE}%"

    # HARD RULE: R:R minimum 2.5
    rr = decision.get("rr_ratio") or 0
    if rr and rr < MIN_RR_RATIO:
        return False, f"R:R {rr:.1f} below minimum {MIN_RR_RATIO}"

    # HARD RULE: News check
    if decision.get("news_check") == "AVOID":
        return False, "High-impact news — avoid trading"

    # HARD RULE: Daily loss limit 3%
    daily_loss = get_daily_pnl_pct(account_balance)
    if daily_loss <= -MAX_DAILY_LOSS_PCT:
        activate_kill_switch(f"Daily loss limit {MAX_DAILY_LOSS_PCT}% hit")
        return False, f"Daily loss limit reached: {daily_loss:.2f}%"

    # HARD RULE: Max 2 simultaneous trades
    open_trades = get_open_trade_count()
    if open_trades >= MAX_OPEN_TRADES:
        return False, f"Max open trades ({MAX_OPEN_TRADES}) reached"

    # Required fields
    for field in ["entry", "sl", "tp"]:
        if not decision.get(field):
            return False, f"Missing required field: {field}"

    return True, "APPROVED"


def calculate_lot_size(account_balance: float, entry: float,
                       sl: float, symbol: str = "XAUUSD") -> tuple:
    """
    Returns (lot_size, risk_usd)
    Always calculates for exactly RISK_PER_TRADE_PCT% of account
    """
    risk_usd = account_balance * (RISK_PER_TRADE_PCT / 100)
    sl_distance = abs(entry - sl)

    if sl_distance == 0:
        return 0.01, risk_usd

    symbol_upper = symbol.upper()
    if "XAU" in symbol_upper:
        # Gold: 1 lot = 100 oz
        contract_size = 100
    elif "NAS" in symbol_upper or "US100" in symbol_upper:
        # NAS100: 1 lot = 1 index point
        contract_size = 1
    elif "BTC" in symbol_upper:
        contract_size = 1
    else:
        contract_size = 1

    raw_lot = risk_usd / (sl_distance * contract_size)
    lot_size = max(0.01, round(raw_lot, 2))

    return lot_size, round(risk_usd, 2)


def get_risk_summary(account_balance: float) -> dict:
    daily_pnl = get_daily_pnl_pct(account_balance)
    in_kz, kz_name = in_killzone()
    return {
        "kill_switch_active": is_killed(),
        "kill_reason": _KILL_REASON,
        "daily_pnl_pct": round(daily_pnl, 2),
        "daily_limit_pct": MAX_DAILY_LOSS_PCT,
        "daily_limit_remaining": round(MAX_DAILY_LOSS_PCT + daily_pnl, 2),
        "open_trades": get_open_trade_count(),
        "max_open_trades": MAX_OPEN_TRADES,
        "in_killzone": in_kz,
        "current_zone": kz_name,
        "min_score_required": MIN_SCORE,
        "min_rr_required": MIN_RR_RATIO,
    }
