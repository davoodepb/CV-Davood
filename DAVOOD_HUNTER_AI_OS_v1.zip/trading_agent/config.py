# ============================================================
#  DAVOOD HUNTER AI OS v1.0 — CONFIG
#  Fill in your API keys in .env file
# ============================================================

import os
from dotenv import load_dotenv

load_dotenv()

# ─── AI API KEYS (add your keys in .env) ─────────────────────
OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY", "")
CLAUDE_API_KEY     = os.getenv("CLAUDE_API_KEY", "")
OPENAI_API_KEY     = os.getenv("OPENAI_API_KEY", "")
DEEPSEEK_API_KEY   = os.getenv("DEEPSEEK_API_KEY", "")
GROQ_API_KEY       = os.getenv("GROQ_API_KEY", "")
GEMINI_API_KEY     = os.getenv("GEMINI_API_KEY", "")

# ─── BROKER ──────────────────────────────────────────────────
BROKER           = os.getenv("BROKER", "paper")
EXCHANGE_API_KEY = os.getenv("EXCHANGE_API_KEY", "")
EXCHANGE_SECRET  = os.getenv("EXCHANGE_SECRET", "")
PAPER_MODE       = os.getenv("PAPER_MODE", "true").lower() == "true"

# ─── RISK MANAGEMENT (Hard Rules) ────────────────────────────
RISK_PER_TRADE_PCT = 1.0   # % risk per trade
MIN_RR_RATIO       = 2.5   # minimum R:R
MAX_DAILY_LOSS_PCT = 3.0   # daily kill switch %
MAX_OPEN_TRADES    = 2     # max simultaneous trades
MIN_SCORE          = 80    # minimum AI score to execute
MIN_CONFIDENCE     = 70    # minimum AI confidence %

# ─── KILLZONES (UTC hours) ────────────────────────────────────
KILLZONES = {
    "London":  (7, 10),   # 08:00-11:00 Lisbon
    "NewYork": (12, 15),  # 13:30-16:00 Lisbon
}

# ─── TELEGRAM ────────────────────────────────────────────────
TELEGRAM_TOKEN   = os.getenv("TELEGRAM_TOKEN", "")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")

# ─── SERVER ──────────────────────────────────────────────────
WEBHOOK_PORT   = 8000
WEBHOOK_SECRET = os.getenv("WEBHOOK_SECRET", "trh_secret_2024")

# ─── DATABASE ────────────────────────────────────────────────
DB_PATH = "trh_journal.db"
