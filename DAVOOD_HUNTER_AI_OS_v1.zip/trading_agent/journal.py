# ============================================================
#  TRADE JOURNAL — SQLite database for all decisions & trades
# ============================================================

import sqlite3
import json
from datetime import datetime
from config import DB_PATH


def init_db():
    """Create tables if they don't exist."""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    c.execute("""
        CREATE TABLE IF NOT EXISTS decisions (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp   TEXT NOT NULL,
            symbol      TEXT,
            event_type  TEXT,
            alert_data  TEXT,
            ai_action   TEXT,
            ai_confidence INTEGER,
            ai_entry    REAL,
            ai_sl       REAL,
            ai_tp       REAL,
            ai_rr       REAL,
            ai_reasoning TEXT,
            executed    INTEGER DEFAULT 0,
            skip_reason TEXT
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS trades (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            decision_id     INTEGER,
            timestamp       TEXT NOT NULL,
            symbol          TEXT,
            side            TEXT,
            entry_price     REAL,
            sl_price        REAL,
            tp_price        REAL,
            lot_size        REAL,
            risk_usd        REAL,
            status          TEXT DEFAULT 'open',
            close_price     REAL,
            pnl_usd         REAL,
            pnl_r           REAL,
            close_time      TEXT,
            FOREIGN KEY(decision_id) REFERENCES decisions(id)
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS daily_stats (
            date        TEXT PRIMARY KEY,
            total_trades INTEGER DEFAULT 0,
            wins        INTEGER DEFAULT 0,
            losses      INTEGER DEFAULT 0,
            pnl_usd     REAL DEFAULT 0,
            pnl_r       REAL DEFAULT 0,
            killed      INTEGER DEFAULT 0
        )
    """)

    conn.commit()
    conn.close()
    print("[DB] Journal initialized.")


def log_decision(alert_data: dict, decision: dict, executed: bool, skip_reason: str = "") -> int:
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    now = datetime.utcnow().isoformat()
    c.execute("""
        INSERT INTO decisions
        (timestamp, symbol, event_type, alert_data, ai_action, ai_confidence,
         ai_entry, ai_sl, ai_tp, ai_rr, ai_reasoning, executed, skip_reason)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
    """, (
        now,
        alert_data.get("symbol"),
        alert_data.get("event"),
        json.dumps(alert_data),
        decision.get("action"),
        decision.get("confidence"),
        decision.get("entry"),
        decision.get("sl"),
        decision.get("tp"),
        decision.get("rr_ratio"),
        decision.get("reasoning"),
        1 if executed else 0,
        skip_reason
    ))
    row_id = c.lastrowid
    conn.commit()
    conn.close()
    return row_id


def log_trade_open(decision_id: int, symbol: str, side: str,
                   entry: float, sl: float, tp: float,
                   lot_size: float, risk_usd: float) -> int:
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        INSERT INTO trades
        (decision_id, timestamp, symbol, side, entry_price, sl_price, tp_price, lot_size, risk_usd)
        VALUES (?,?,?,?,?,?,?,?,?)
    """, (decision_id, datetime.utcnow().isoformat(), symbol, side,
          entry, sl, tp, lot_size, risk_usd))
    trade_id = c.lastrowid
    conn.commit()
    conn.close()
    return trade_id


def log_trade_close(trade_id: int, close_price: float, pnl_usd: float, pnl_r: float):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    conn.execute("""
        UPDATE trades SET status='closed', close_price=?, pnl_usd=?, pnl_r=?, close_time=?
        WHERE id=?
    """, (close_price, pnl_usd, pnl_r, datetime.utcnow().isoformat(), trade_id))

    today = datetime.utcnow().strftime("%Y-%m-%d")
    conn.execute("""
        INSERT INTO daily_stats(date) VALUES(?) ON CONFLICT(date) DO NOTHING
    """, (today,))
    conn.execute("""
        UPDATE daily_stats SET
            total_trades = total_trades + 1,
            wins  = wins  + ?,
            losses= losses+ ?,
            pnl_usd = pnl_usd + ?,
            pnl_r   = pnl_r   + ?
        WHERE date=?
    """, (1 if pnl_usd > 0 else 0, 1 if pnl_usd <= 0 else 0,
          pnl_usd, pnl_r, today))
    conn.commit()
    conn.close()


def get_daily_pnl_pct(account_balance: float) -> float:
    """Return today's P&L as % of account."""
    today = datetime.utcnow().strftime("%Y-%m-%d")
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT pnl_usd FROM daily_stats WHERE date=?", (today,))
    row = c.fetchone()
    conn.close()
    if not row:
        return 0.0
    return (row[0] / account_balance) * 100


def get_open_trade_count() -> int:
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM trades WHERE status='open'")
    count = c.fetchone()[0]
    conn.close()
    return count
